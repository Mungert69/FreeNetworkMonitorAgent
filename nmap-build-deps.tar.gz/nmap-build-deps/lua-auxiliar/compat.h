#ifndef AUXILIAR_COMPAT_H
#define AUXILIAR_COMPAT_H

/* Compatibility helpers */

// On older Lua versions use shorter names
#ifndef luaL_len
#define luaL_len(L, idx) lua_objlen(L, idx)
#endif

#endif /* AUXILIAR_COMPAT_H */

